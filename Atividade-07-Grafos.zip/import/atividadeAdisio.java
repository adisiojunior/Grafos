package classexamples;

import java.util.Set;

import org.jgrapht.Graph;
import org.jgrapht.graph.SimpleGraph;
import org.jgrapht.graph.SimpleWeightedGraph;

import util.DefaultVertex;
import util.ImportUtil;
import util.PrintUtil;
import util.RelationshipWeightedEdge;
import util.VertexEdgeUtil;

public class atividadeAdisio {
	
	private static final String NL = System.getProperty("line.separator");
	private static final String sep = System.getProperty("file.separator");

	private static final String graphpathname = "graphs" + sep;

	public static void main(String[] args) {


		Graph<DefaultVertex, RelationshipWeightedEdge> unweightedgraph = 
				new SimpleGraph <> (VertexEdgeUtil.createDefaultVertexSupplier(), 
			            VertexEdgeUtil.createRelationshipWeightedEdgeSupplier(),false);
		Set <DefaultVertex> VU = unweightedgraph.vertexSet();
    Set <RelationshipWeightedEdge> EU = unweightedgraph.edgeSet();

    //Criando um grafo sem pesos
		ImportUtil.importGraphMultipleCSV(unweightedgraph, 
					graphpathname + "pessoas.csv","Login","Nome",
				    graphpathname + "amizades.csv", "Pessoa1", "Pessoa2", null, true, false);
    System.out.println(NL);
		PrintUtil.printGraph(unweightedgraph, "Grafo sem Pesos");
		
		//Criando um grafo com pesos
		Graph<DefaultVertex, RelationshipWeightedEdge> weightedgraph = 
				new SimpleWeightedGraph <> (VertexEdgeUtil.createDefaultVertexSupplier(), 
			            VertexEdgeUtil.createRelationshipWeightedEdgeSupplier());
		ImportUtil.importGraphMultipleCSV(weightedgraph, 
					graphpathname + "pessoas.csv","Login","Nome",
					graphpathname + "amizades.csv", "Pessoa1", "Pessoa2", "Tempo", true, true);
		PrintUtil.printWeightedGraph(weightedgraph, NL + "Grafo com Pesos");

	}
}
