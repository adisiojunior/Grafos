import classexamples.atividadeAdisio;

class Main {

  public static void main(String[] args) {
    atividadeAdisio.main(args);
  }
}